<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,">
        <?= stylesheet_link_tag('apps/prepare/application') ?>
        <?= javascript_include_tag('apps/prepare/application') ?>
        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div id="wrapper">

        </div>
    </body>
</html>