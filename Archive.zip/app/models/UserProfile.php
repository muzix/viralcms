<?php

class UserProfile extends \Eloquent {
	protected $fillable = [];
    public $timestamps = false;
    protected $table = 'user_profiles';
}