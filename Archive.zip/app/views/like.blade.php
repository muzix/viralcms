@extends('master')

@section('content')
    <div class="like-image"></div>
@stop