<?php
// app/config/facebook.php

// Facebook app Config
return array(
        'appId' => '631750210234079',
        'secret' => 'f02acc58bd440d8b78f504f202ba67c5',
        'appUrl' => 'https://apps.facebook.com/631750210234079/',
        'pageTabUrl' => 'https://www.facebook.com/hoang1210/app_631750210234079',
        'defaultPassword' => 'g@l@xy'
    );