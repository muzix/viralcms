<html>
    <body>
        <h1>Laravel Quickstart</h1>

        @yield('content')
    </body>
</html>