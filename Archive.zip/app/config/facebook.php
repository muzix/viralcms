<?php
// app/config/facebook.php

// Facebook app Config
return array(
        'appId' => '850948594931878',
        'secret' => '79ce72cd746925408ae22096e15b3b4d',
        'appUrl' => 'https://apps.facebook.com/565555370189507/',
        'pageTabUrl' => 'https://www.facebook.com/hoang1210/app_565555370189507',
        'defaultPassword' => 'g@l@xy'
    );